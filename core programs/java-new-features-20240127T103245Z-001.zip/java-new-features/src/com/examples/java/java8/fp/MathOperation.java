package com.examples.java.java8.fp;

@FunctionalInterface
public interface MathOperation {
    public int compute(int a, int b);
}
