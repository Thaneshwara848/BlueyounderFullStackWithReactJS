package com.examples.java.java17.pattern;

import java.util.List;

/**
 * Java 17 - Preview Feature
 */
public class SwitchCasePatternMatchingDemo {
    public static void main(String[] args) {
//        System.out.println(getLength("Heelo"));
    }

//    public static int getLength(Object obj) {
//        return switch (obj) {
//            case String s -> s.length(); // variable pattern
//            case List list && !list.isEmpty() -> list.size(); // type pattern
//            case null -> 0;
//            default -> -1;
//
//        };
//        return 0;
//    }
}
