package com.ibm.bookprice.BookStoreWeb.dto;

public class BookPriceInfo {
	private Integer bookId;
	private double price;
	private double offer;
	public Integer getBookId() {
		return bookId;
	}
	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getOffer() {
		return offer;
	}
	public void setOffer(double offer) {
		this.offer = offer;
	}

	

}
